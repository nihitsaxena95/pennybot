import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class ContextService {

constructor(private http:Http) { }

  url:string="http://localhost:8000/addcontext";


addContext(intent):Observable<any> {
  	return this.http.post(this.url,{data:intent})
  	.map((res:Response)=>{
  		return res.json();
  	})
  }

addSynonym(data): Observable<any> {
    return this.http
    .put(this.url,{data: data})
    .map((res: Response)=>{
      return res.json()
    })
  }
}
