import { Component, OnInit } from '@angular/core';
import { ContextService } from './context.service';
import { ModalDirective } from 'ngx-bootstrap/modal/modal.component';

@Component({
  selector: 'app-context',
  templateUrl: './context.component.html',
  styleUrls: ['./context.component.scss'],
  providers:[ContextService]
})
export class ContextComponent implements OnInit {

  res:any={};
	ref:any={};
	name:any;
	context:any;
	labelname:any;
	temp:any;
	propname:any;
  constructor(private contextService:ContextService) { }

  ngOnInit() {
  }

addIntent(){
	const val={
		labelname:this.name,
		propname:this.context
	}
	this.contextService.addContext(val)
	.subscribe((res)=>{
		this.res=res;
	})
}

addSynonym(){
	const data= {
		labelname : this.labelname,
		propname:this.propname,
		syn:this.temp
	}
	this.contextService.addSynonym(data)
	.subscribe((ref)=>{
		this.ref=ref;
	})
}

}


